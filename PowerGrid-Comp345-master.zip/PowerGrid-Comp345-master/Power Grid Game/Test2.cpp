#include<fstream>
#include<string>
#include<iostream>
#include"MapLoader.h"
#include"Map.h"


/*int main(){

	std::string filename = "C:/Users/steve/Desktop/C++ Programming/UsaMap.txt";
	std::ifstream file;
	file.open(filename);
	MapLoader m = MapLoader();

	m.loadMap(file);
	m.connectCities();
	Graph::printGraph(m.getMap());

	system("pause");
	return 0;
}*/