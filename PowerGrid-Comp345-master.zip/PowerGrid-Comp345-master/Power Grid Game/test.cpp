#include<iostream>
#include<string>
#include"Resource.h"
#include"House.h"



/*int main() {

	Resource oil = Resource(10, "steve");
	House red = House(22,"Red","steve");

	std::cout << oil.getTokens() << std::endl;
	std::cout << red.getColor() << std::endl;


	system("pause");
	return 0;
}*/